using Microsoft.VisualStudio.TestTools.UnitTesting;
using CarRentalApp.Models;
using CarRentalAppLibrary;
using System;
using System.Collections.Generic;

namespace CarRentalAppTests
{
    [TestClass]
    public class UnitTestReserve
    {
        [TestMethod]
        public void TestMethodReserve()
        {
            CarReservation reservation = new CarReservation();

            reservation.Vehicles = new List<Vehicle>() {
            new Vehicle() { VehicleID = 1, Model = "2018 Tesla Model 3" },
            new Vehicle() { VehicleID = 2, Model = "2018 Honda SUV" },
            new Vehicle() { VehicleID = 3, Model = "2017 Honda SUV" },
            new Vehicle() { VehicleID = 4, Model = "2018 Ford Focus" },
            new Vehicle() { VehicleID = 5, Model = "2017 Ford SUV" }
            };

            DateTime fromDate = new DateTime();
            int days = 3;
            bool status = reservation.reserve(fromDate, days);
            Assert.AreEqual(status, true);

            DateTime fromDate2 = fromDate.AddDays(6);
            int days2 = 2;
            bool status2 = reservation.reserve(fromDate2, days2);
            Assert.AreEqual(status2, true);

            DateTime fromDate3 = fromDate.AddDays(4);
            int days3 = 2;
            bool status3 = reservation.reserve(fromDate3, days3);
            Assert.AreEqual(status3, true);

            DateTime fromDate4 = fromDate.AddDays(4);
            int days4 = 2;
            bool status4 = reservation.reserve(fromDate3, days4);
            Assert.AreEqual(status4, false);
        }
    }
}
