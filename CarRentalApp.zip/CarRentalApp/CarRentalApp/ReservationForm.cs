﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CarRentalApp.Models;
using CarRentalAppLibrary;

namespace CarRentalApp
{
    public partial class ReservationForm : Form
    {
        CarReservation carReservation = new CarReservation();

        public ReservationForm()
        {
            InitializeComponent();
            txtDays.Text = "1";
        }

        private void ReservationForm_Load(object sender, EventArgs e)
        {
            cmbAvailableCars.DisplayMember = "Name";
            cmbAvailableCars.ValueMember = "Id";

            foreach (Vehicle car in carReservation.Vehicles)
            {                
                cmbAvailableCars.Items.Add(car.Model);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Debug.WriteLine("Selected Car:"+cmbAvailableCars.SelectedText);
            Debug.WriteLine("FromDate:"+fromDateTime.Value.Date.ToString());
            Debug.WriteLine("No. Of days:" + txtDays);
            int days = Int32.Parse(txtDays.Text);
            updateStatus(carReservation.reserve(fromDateTime.Value.Date, days));
        }

        private void updateStatus(bool status)
        {
            if (status)
                txtStatus.Text = "Reserved";
            else
                txtStatus.Text = "Not Available";
        }

        private void cmbAvailableCars_SelectedIndexChanged(object sender, EventArgs e)
        {
            carReservation.SelectedModel = cmbAvailableCars.SelectedIndex+1;
            Console.WriteLine("{0}. selected Model:{1}", carReservation.SelectedModel, cmbAvailableCars.SelectedText);
        }

        private void btnAvailability_Click(object sender, EventArgs e)
        {
            DateTime ReserveDateTime = this.fromDateTime.Value.Date;
            int reserveDays = Int32.Parse(txtDays.Text);
            bool available = carReservation.checkAvailability(ReserveDateTime, reserveDays);
            updateStatus(available);
        }

    }
}
