﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CarRentalApp.Models
{
    public class Reservation
    {
        public int ReservationID { get; set; }
        public int VehicleID { get; set; }
        public int CustomerID { get; set; }
        public DateTime ReserveDateTime { get; set; }
    }
}