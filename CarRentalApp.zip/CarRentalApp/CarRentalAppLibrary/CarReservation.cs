﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CarRentalApp.Models;

namespace CarRentalAppLibrary
{
    public class CarReservation
    {
        public List<Vehicle> Vehicles;
        public List<Reservation> Reservations;
        public int SelectedModel;
        public int ReservationID = 1;

        public CarReservation()
        {
            Reservations = new List<Reservation>();
            initialize();
        }

        private void initialize()
        {
            Vehicles = new List<Vehicle>() {
            new Vehicle() { VehicleID = 1, Model = "2018 Tesla Model 3" },
            new Vehicle() { VehicleID = 2, Model = "2018 Honda SUV" },
            new Vehicle() { VehicleID = 3, Model = "2017 Honda SUV" },
            new Vehicle() { VehicleID = 4, Model = "2018 Ford Focus" },
            new Vehicle() { VehicleID = 5, Model = "2017 Ford SUV" }
            };
        }

        private string getStatus(bool status)
        {
            if (status)
                return "Reserved";
            else
                return "Not Available";
        }

        public bool reserve(DateTime fromDate, int reserveDays)
        {
            DateTime ReserveDateTime = fromDate;
            bool available = false;

            if (Reservations.Count() >= 0 && checkAvailability(ReserveDateTime, reserveDays))
            {
                for (int i = 0; i < reserveDays; i++)
                {
                    Reservation r = new Reservation();
                    r.VehicleID = SelectedModel;
                    r.ReserveDateTime = ReserveDateTime;
                    r.ReservationID = ReservationID;
                    Reservations.Add(r);
                    Console.WriteLine("{0}. Model: {1}, ReserveDate:{2}", r.ReservationID, r.VehicleID, r.ReserveDateTime);

                    ReserveDateTime = ReserveDateTime.AddDays(i + 1);
                    ReservationID++;
                }
                available = true;
            }

            //displayReservedVehicles();


            return available;
        }

        public bool checkAvailability(DateTime reservedDateTime, int days)
        {
            Console.WriteLine("checkAvailability() ...");

            int available = 0;

            displayReservedVehicles();

            for (int i = 0; i < days; i++)
            {
                DateTime ReserveDateTime = reservedDateTime.AddDays(i);
                Console.WriteLine("Model: {0}, ReserveDate:{1}", SelectedModel, ReserveDateTime);

                var reserved_cars = Reservations.Where(c => c.VehicleID == SelectedModel && c.ReserveDateTime == ReserveDateTime).ToList();

                Console.WriteLine("reserved_cars Count:{0}", reserved_cars.Count());

                if (reserved_cars.Count() > 0)
                    available++;
            }

            if (available > 0)
                return false;
            else
                return true;

        }

        public void displayReservedVehicles()
        {
            Console.WriteLine("** ReservedVehicles:");

            foreach (Reservation r in Reservations)
            {
                Console.WriteLine("{0}. Model: {1}, ReserveDate:{2}", r.ReservationID, r.VehicleID, r.ReserveDateTime);
            }
            Console.WriteLine("** ");
        }

    }
}
